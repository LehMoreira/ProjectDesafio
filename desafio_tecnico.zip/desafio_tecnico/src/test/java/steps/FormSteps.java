package steps;


import io.cucumber.java.pt.*;
import pages.EnterInsurantDataPage;
import pages.EnterProductDataPage;
import pages.EnterVehicleDataPage;
import pages.SelectPriceOptionPage;
import pages.SendQuotePage;

import org.openqa.selenium.WebDriver;


import hocks.Hooks;

public class FormSteps {

    private WebDriver driver;
    private EnterVehicleDataPage vehicleDataPage;
    private EnterInsurantDataPage insurantDataPage;
    private EnterProductDataPage productDataPage;
    private SelectPriceOptionPage  priceOptionPage;
    private SendQuotePage quotePage;
    public FormSteps() {
        this.driver = Hooks.getDriver();
    }
    @Dado("que estou na página de formulário de cotação")
    public void abrirPaginaDeFormulario() {
        
        vehicleDataPage = new EnterVehicleDataPage(driver);
        insurantDataPage = new EnterInsurantDataPage(driver);
        productDataPage = new EnterProductDataPage(driver);
        priceOptionPage = new SelectPriceOptionPage(driver);
        quotePage = new SendQuotePage(driver);
    }

    @Quando("eu preencho a aba \"Enter Vehicle Data\" e prossigo")
    public void preencherVehicleData() {
        vehicleDataPage.selecionarMake("BMW");
        vehicleDataPage.preencherEnginePerformance("120");
        vehicleDataPage.preencherDateOfManufacture("01/01/2020");
        vehicleDataPage.selecionarNumberOfSeats("4");
        vehicleDataPage.selecionarFuelType("Petrol");
        vehicleDataPage.preencherListPrice("30000");
        vehicleDataPage.preencherLicensePlateNumber("ABC1234");
        vehicleDataPage.preencherAnnualMileage("15000");
        vehicleDataPage.clicarNext();
    }
    @Quando("eu preencho a aba \"Enter Insurant Data\" e prossigo")
    public void preencherInsurantData() {
    	insurantDataPage = new EnterInsurantDataPage(driver);
        insurantDataPage.preencherFirstName("Leticya");
        insurantDataPage.preencherLastName("Moreira");
        insurantDataPage.preencherDateOfBirth("02/10/2006");
        insurantDataPage.selecionarGender("Female");
        insurantDataPage.preencherStreetAddress("Rua Exemplo, 123");
        insurantDataPage.selecionarCountry("Brazil");
        insurantDataPage.preencherZipCode("12345678");
        insurantDataPage.preencherCity("Campina Grande");
        insurantDataPage.selecionarOccupation("Unemployed");
        insurantDataPage.selecionarHobbies("Speeding", "Bungee Jumping");
        insurantDataPage.preencherWebsite("exemplo.com.br");
        insurantDataPage.uploadPicture("C:\\Users\\Letícya\\Pictures\\15 years\\IMG_6944.jpg");
        insurantDataPage.clicarNext();
    }

    @Quando("eu preencho a aba \"Enter Product Data\" e prossigo")
    public void preencherProductData() {
    	productDataPage = new EnterProductDataPage(driver);
        productDataPage.preencherStartDate("01/01/2023");
        productDataPage.selecionarInsuranceSum("3.000.000,00");
        productDataPage.selecionarMeritRating("Bonus 5");
        productDataPage.selecionarDamageInsegurance("No Coverage");
        productDataPage.selecionarOptionalProducts("Euro Protection");
        productDataPage.selecionarCourtesyCar("No");
        productDataPage.clicarNext();
    }

    @Quando("eu seleciono uma opção de preço e prossigo")
    public void selecionarOpcaoDePreco() {
        priceOptionPage.selecionarOpcaoDePreco("Gold");
        priceOptionPage.clicarNext();
    }

    @Quando("eu preencho a aba \"Send Quote\" e envio")
    public void preencherSendQuote() {
    	    quotePage.preencherEmail("leti@gmail.com");
    	    quotePage.preencherTelefone("83999044189");
    	    quotePage.preencherUsername("leti");
    	    quotePage.preencherPassword("Ll1234");
    	    quotePage.preencherConfirmPassword("Ll1234");
    	    quotePage.preencherComments(" ");
    	    quotePage.clicarSend();
    }

    @Então("eu vejo a mensagem \"Sending e-mail success!\"")
    public void verificarMensagemDeSucesso() {
        boolean isMessageDisplayed = quotePage.verificarMensagemSucesso();

        if (isMessageDisplayed) {
            System.out.println("A mensagem de sucesso foi exibida com sucesso.");
        } else {
            System.out.println("A mensagem de sucesso não foi exibida.");
        }
    }

}