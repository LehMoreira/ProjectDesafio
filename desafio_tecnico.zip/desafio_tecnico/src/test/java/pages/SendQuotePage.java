package pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SendQuotePage {
    private WebDriver driver;
    private WebDriverWait wait;

    public SendQuotePage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    public void preencherEmail(String email) {
        WebElement emailField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("email")));
        emailField.clear();
        emailField.sendKeys(email);
    }

    public void preencherTelefone(String telefone) {
        WebElement phoneField = driver.findElement(By.id("phone"));
        phoneField.clear();
        phoneField.sendKeys(telefone);
    }

    public void preencherUsername(String username) {
        WebElement usernameField = driver.findElement(By.id("username"));
        usernameField.clear();
        usernameField.sendKeys(username);
    }

    public void preencherPassword(String password) {
        WebElement passwordField = driver.findElement(By.id("password"));
        passwordField.clear();
        passwordField.sendKeys(password);
    }

    public void preencherConfirmPassword(String confirmPassword) {
        WebElement confirmPasswordField = driver.findElement(By.id("confirmpassword"));
        confirmPasswordField.clear();
        confirmPasswordField.sendKeys(confirmPassword);
    }

    public void preencherComments(String comments) {
        WebElement commentsField = driver.findElement(By.id("Comments"));
        commentsField.clear();
        commentsField.sendKeys(comments);
    }

    public void clicarSend() {
        WebElement sendButton = driver.findElement(By.id("sendemail"));
        sendButton.click();
    }
    public boolean verificarMensagemSucesso() {
        WebElement successMessage = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[text()='Sending e-mail success!']")));
        return successMessage.isDisplayed();
    }
}
