package pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class EnterProductDataPage {
	private WebDriver driver;
    private WebDriverWait wait;

    public EnterProductDataPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver,Duration.ofSeconds(10));
    }
    public void preencherStartDate(String startDate) {
        WebElement dateField = driver.findElement(By.id("startdate"));
        dateField.clear();
        dateField.sendKeys(startDate);
    }
    public void selecionarInsuranceSum(String insurance) {
        WebElement insuranceDropdown = driver.findElement(By.id("insurancesum"));
        new Select(insuranceDropdown).selectByVisibleText(insurance);
    }

    public void selecionarMeritRating(String meritRating) {
        WebElement meritDropdown = driver.findElement(By.id("meritrating"));
        new Select(meritDropdown).selectByVisibleText(meritRating);
    }
    public void selecionarDamageInsegurance(String damageInsegurance) {
        WebElement damageDropdown = driver.findElement(By.id("damageinsurance"));
        new Select(damageDropdown).selectByVisibleText(damageInsegurance);
    }
    public void selecionarOptionalProducts(String... products) {
        for (String product : products) {
            WebElement productCheckbox = wait.until(ExpectedConditions.visibilityOfElementLocated(
                    By.xpath("//label[contains(text(),'" + product + "')]/preceding-sibling::input")));
            if (!productCheckbox.isSelected()) {
                productCheckbox.click();
            }
        }
    }
    public void selecionarCourtesyCar(String courtesyCar) {
        WebElement courtesyDropdown = driver.findElement(By.id("courtesycar"));
        new Select(courtesyDropdown).selectByVisibleText(courtesyCar);
    }
    public void clicarNext() {
        WebElement nextButton = wait.until(ExpectedConditions.elementToBeClickable(By.id("nextselectpriceoption")));
        nextButton.click();
    }
}
