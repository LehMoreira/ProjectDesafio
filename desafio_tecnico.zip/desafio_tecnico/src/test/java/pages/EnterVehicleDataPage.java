package pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;


public class EnterVehicleDataPage {

    private WebDriver driver;
    private WebDriverWait wait;

    public EnterVehicleDataPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver,Duration.ofSeconds(10));
    }

    public void selecionarMake(String make) {
        WebElement makeDropdown = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("make")));
        new Select(makeDropdown).selectByVisibleText(make);
    }

    public void preencherEnginePerformance(String performance) {
        WebElement performanceField = driver.findElement(By.id("engineperformance"));
        performanceField.clear();
        performanceField.sendKeys(performance);
    }

    public void preencherDateOfManufacture(String manufactureDate) {
        WebElement dateField = driver.findElement(By.id("dateofmanufacture"));
        dateField.clear();
        dateField.sendKeys(manufactureDate);
    }

    public void selecionarNumberOfSeats(String seats) {
        WebElement seatsDropdown = driver.findElement(By.id("numberofseats"));
        new Select(seatsDropdown).selectByVisibleText(seats);
    }

    public void selecionarFuelType(String fuelType) {
        WebElement fuelDropdown = driver.findElement(By.id("fuel"));
        new Select(fuelDropdown).selectByVisibleText(fuelType);
    }

    public void preencherListPrice(String price) {
        WebElement priceField = driver.findElement(By.id("listprice"));
        priceField.clear();
        priceField.sendKeys(price);
    }

    public void preencherLicensePlateNumber(String licensePlate) {
        WebElement licenseField = driver.findElement(By.id("licenseplatenumber"));
        licenseField.clear();
        licenseField.sendKeys(licensePlate);
    }

    public void preencherAnnualMileage(String mileage) {
        WebElement mileageField = driver.findElement(By.id("annualmileage"));
        mileageField.clear();
        mileageField.sendKeys(mileage);
    }

    public void clicarNext() {
        WebElement nextButton = driver.findElement(By.id("nextenterinsurantdata"));
        nextButton.click();
    }
}