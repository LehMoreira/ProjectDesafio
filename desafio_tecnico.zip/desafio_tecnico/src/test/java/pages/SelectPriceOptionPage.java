package pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SelectPriceOptionPage {
    private WebDriver driver;
    private WebDriverWait wait;

    public SelectPriceOptionPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    public void selecionarOpcaoDePreco(String opcao) {
        String opcaoId = "";

        switch (opcao.toLowerCase()) {
            case "silver":
                opcaoId = "selectsilver";
                break;
            case "gold":
                opcaoId = "selectgold";
                break;
            case "platinum":
                opcaoId = "selectplatinum";
                break;
            case "ultimate":
                opcaoId = "selectultimate";
                break;
            default:
                throw new IllegalArgumentException("Opção de preço inválida: " + opcao);
        }

        WebElement opcaoRadio = wait.until(ExpectedConditions.elementToBeClickable(By.id(opcaoId)));
        opcaoRadio.click();
    }

    public void clicarNext() {
        WebElement nextButton = wait.until(ExpectedConditions.elementToBeClickable(By.id("nextsendquote")));
        nextButton.click();
    }
}
