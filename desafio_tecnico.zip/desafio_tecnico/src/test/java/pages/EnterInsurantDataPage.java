package pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class EnterInsurantDataPage {
	private WebDriver driver;
    private WebDriverWait wait;

    public EnterInsurantDataPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver,Duration.ofSeconds(10));
    }
    public void preencherFirstName(String first) {
        WebElement firstnameField = driver.findElement(By.id("firstname"));
        firstnameField.clear();
        firstnameField.sendKeys(first);
    }
    public void preencherLastName(String last) {
        WebElement lastnameField = driver.findElement(By.id("lastname"));
        lastnameField.clear();
        lastnameField.sendKeys(last);
    }
    public void preencherDateOfBirth(String birthDate) {
        WebElement dateField = driver.findElement(By.id("dateofbirth"));
        dateField.clear();
        dateField.sendKeys(birthDate);
    }
    public void selecionarGender(String gender) {
        String genderId = gender.equalsIgnoreCase("Male") ? "gendermale" : "genderfemale";
        WebElement genderRadio = driver.findElement(By.id(genderId));
        genderRadio.click();
    }

    public void preencherStreetAddress(String streetAddress) {
        WebElement streetField = driver.findElement(By.id("streetaddress"));
        streetField.clear();
        streetField.sendKeys(streetAddress);
    }

    public void selecionarCountry(String country) {
        WebElement countryDropdown = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("country")));
        new Select(countryDropdown).selectByVisibleText(country);
    }

    public void preencherZipCode(String zipCode) {
        WebElement zipCodeField = driver.findElement(By.id("zipcode"));
        zipCodeField.clear();
        zipCodeField.sendKeys(zipCode);
    }

    public void preencherCity(String city) {
        WebElement cityField = driver.findElement(By.id("city"));
        cityField.clear();
        cityField.sendKeys(city);
    }

    public void selecionarOccupation(String occupation) {
        WebElement occupationDropdown = driver.findElement(By.id("occupation"));
        new Select(occupationDropdown).selectByVisibleText(occupation);
    }

    public void selecionarHobbies(String... hobbies) {
        for (String hobby : hobbies) {
            WebElement hobbyCheckbox = driver.findElement(By.xpath("//label[contains(text(),'" + hobby + "')]/preceding-sibling::input"));
            if (!hobbyCheckbox.isSelected()) {
                hobbyCheckbox.click();
            }
        }
    }

    public void preencherWebsite(String website) {
        WebElement websiteField = driver.findElement(By.id("website"));
        websiteField.clear();
        websiteField.sendKeys(website);
    }
    public void uploadPicture(String filePath) {
        WebElement uploadField = driver.findElement(By.id("picturecontainer"));
        uploadField.sendKeys(filePath);
    }


    public void clicarNext() {
        WebElement nextButton = driver.findElement(By.id("nextenterproductdata"));
        nextButton.click();
    }

}
